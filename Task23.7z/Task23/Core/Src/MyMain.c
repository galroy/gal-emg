/*
 * MyMain.c
 *
 *  Created on: Jul 5, 2022
 *      Author: student
 */
#include "main.h"
#include <string.h>
#include <stdio.h>

#include "rtc.h"
#include "buzzer.h"


#define MAX_BUFFER_LENGTH 50
#define MY_PASS 2042
#define NUM_PASS_ERR 3
#define NUM_PASS_5_MIN_ERR 3
#define LOCK_30_SEC 5 //30
#define NUM_5_MIN_IN_SEC 20//5*60=300

extern UART_HandleTypeDef huart2;
extern I2C_HandleTypeDef hi2c1;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim6;

Rtc rtc;
Buzzer buzzer;
static uint8_t passError = 0;
static uint8_t passLock5min = 0;
static uint8_t sysLock = 0;

static uint8_t _cmdbuffer[MAX_BUFFER_LENGTH];
static int _cmdcount = 0;
static int _cmdprint = 0;

int _write(int fd, char* ptr, int len) {
    HAL_UART_Transmit(&huart2, (uint8_t *) ptr, len, HAL_MAX_DELAY);
    return len;
}
uint8_t isSys5MinLock(){
	uint8_t timeToUnLock;
	uint8_t ret = 1;
	getTimeToUlock(&rtc,&timeToUnLock);
	if(getSecFrom01_01_00(&rtc) - timeToUnLock <= 0){
		ret = 0;
	}
	return ret;
}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	/*ledOnTimerInterrupt(&ledB);
	ledOnTimerInterrupt(&ledR);

	buttonOnTimerInterrupt(&buttonSw1);
	buttonOnTimerInterrupt(&buttonSw2);
*/
	buzzerOnTimerInterrupt(&buzzer);
	static uint32_t milsec = 0;
	static uint32_t sec = 0;

	if (htim == &htim6) {
		if (milsec % 1000 == 0) {
			if (isSys5MinLock()) {
				sysLock = 1;
			} else {
				sysLock = 0;
			}
			if (sysLock == 0) {

				if (passError == NUM_PASS_ERR) {
					sec++;
					if (sec == LOCK_30_SEC) {
						sec = 0;
						passError = 0;

						//HAL_TIM_Base_Stop_IT(&htim6);
						printf("system unlock\n\r");
					}

				}
			}
		}
		milsec++;

	}
}


static int isCommTaskLock(){
	uint8_t ret = 0;
	if(passError >= NUM_PASS_ERR || passLock5min > NUM_PASS_5_MIN_ERR || sysLock == 1){
		ret = 1;
	}
	return ret;
}
static int commTask()
{
	uint8_t ch;
	if(isCommTaskLock() == 1){
		return 0;
	}

	HAL_StatusTypeDef Status = HAL_UART_Receive(&huart2, &ch, 1, 10);
	if (Status != HAL_OK)
	{
		if ((huart2.Instance->ISR & USART_ISR_ORE) != 0)
		{
			__HAL_UART_CLEAR_OREFLAG(&huart2);
		}

		// here we have a time to print the command
		while (_cmdprint < _cmdcount)
		{
			HAL_UART_Transmit(&huart2, &_cmdbuffer[_cmdprint++], 1, 0xFFFF);
		}

		return 0;
	}

	if (ch == '\r' || ch == '\n')
	{
		// here we have a time to print the command
		while (_cmdprint < _cmdcount)
		{
			HAL_UART_Transmit(&huart2, &_cmdbuffer[_cmdprint++], 1, 0xFFFF);
		}

		HAL_UART_Transmit(&huart2, (uint8_t*)"\r\n", 2, 0xFFFF);

		_cmdbuffer[_cmdcount] = 0;
		_cmdcount = 0;
		_cmdprint = 0;

		// command is ready
		return 1;
	}
	else if (ch == '\b')
	{
		char bs[] = "\b \b";
		_cmdcount--;
		_cmdprint--;
		HAL_UART_Transmit(&huart2, (uint8_t*)bs, strlen(bs), 0xFFFF);
	}
	else
	{
		if (_cmdcount >= MAX_BUFFER_LENGTH)
		{
			_cmdcount = 0;
			_cmdprint = 0;
		}

		_cmdbuffer[_cmdcount++] = ch;
	}

	return 0;
}

static void LockSystem5Min(){
	printf("Lock sys 5 min");
	uint8_t curtimeSec;
	curtimeSec = getSecFrom01_01_00(&rtc);
	curtimeSec = curtimeSec + NUM_5_MIN_IN_SEC; //5 min
	setTimeToUlock(&rtc,&curtimeSec);
}

static void handleCommand()
{
	char cmd[20];
	int param;

	int params = sscanf((const char*)_cmdbuffer, "%s %d", cmd, &param);

	if (params == 0)
	{
		return;
	}

	if (strcmp(cmd, "pass") == 0 && params > 0 )
	{
		uint32_t passFromMem;
		getPass(&rtc, &passFromMem);
		if(passFromMem == param && passError < NUM_PASS_ERR){
			printf("password Ok\n\r");
			passError = 0;
			passLock5min = 0;
			HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 1);
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, 0);
		}else{
			if(passError <= NUM_PASS_ERR){
				passError++;
			}
			printf("Invalid password try num %d\n\r",passError);
			if(passError >= NUM_PASS_ERR){
				if(passLock5min <= NUM_PASS_5_MIN_ERR){
					printf("passLock5min=%d\n\r",passLock5min);
					passLock5min++;
				}else{
					LockSystem5Min();
					printf("passLock5min=%d\n\r",passLock5min);
				}

				printf("system lock for 30 sec\n\r");
				//HAL_TIM_Base_Start_IT(&htim6);
			}
			HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 0);
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, 1);
			buzzerPlayTone(&buzzer, 300);


		}

		/*_brightnessMode = 0;
		ledOn(&ledB);*/
	}
	/*else if (strcmp(cmd, "half") == 0)
	{
		_brightnessMode = 0;
		ledHalf(&ledB);
	}
	else if (strcmp(cmd, "blink") == 0)
	{
		ledBlink(&ledB, 300);
	}
	else if (strcmp(cmd, "off") == 0)
	{
		_brightnessMode = 0;
		ledOff(&ledB);
	}
	else if (strcmp(cmd, "play") == 0)
	{
		_playToneMode = 0;
		buzzerPlay(&buzzer);
	}
	else if (strcmp(cmd, "pause") == 0)
	{
		_playToneMode = 0;
		buzzerPause(&buzzer);
	}
	else if (strcmp(cmd, "tone") == 0 && params > 0)
	{
		_playToneMode = 1;
		buzzerPlayTone(&buzzer, param);
	}
	else if (strcmp(cmd, "set") == 0 && params > 1)
	{
		_brightnessMode = 0;
		ledBrightness(&ledB, param);
	}
	else if (strcmp(cmd, "brightness") == 0)
	{
		_brightnessMode = 1;
	}
	else
	{
		printf("Invalid command\r\n");
		return;
	}*/
}


int mainLoop(){

	HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);
	HAL_TIM_Base_Start_IT(&htim6);
	HAL_NVIC_EnableIRQ(ADC1_2_IRQn);
	initRTC(&rtc, &hi2c1);
	buzzerInit(&buzzer, &htim3);
	setPass(&rtc, MY_PASS);
	if(isSys5MinLock()){
		sysLock = 1;
	}else{
		sysLock = 0;
	}
	//SetClockTo01_01_00(&rtc);//one time

	while(1){
		if (commTask()) {
			handleCommand();
		}

	}
}
