/*
 * rtc.c
 *
 *  Created on: Jul 5, 2022
 *      Author: student
 */
#include "rtc.h"
#define PASS_ADRR 8
#define TIME_TO_UNLOCK 9


void initRTC(Rtc *rtc , I2C_HandleTypeDef* hi2c){

	rtc->sec = 0;
	rtc->min = 0;
	rtc->hour = 0;
	rtc->day = 0;
	rtc->month = 0;
	rtc->year = 0;
	rtc->hi2c = hi2c;
}

int setPass(Rtc *rtc,uint32_t pass){
	return HAL_I2C_Mem_Write(rtc->hi2c,0xD0,PASS_ADRR,1,(uint8_t *)&pass,sizeof(pass),0xFF);
}

int setTimeToUlock(Rtc *rtc,uint8_t *timeToUnLock){
	return HAL_I2C_Mem_Write(rtc->hi2c,0xD0,TIME_TO_UNLOCK,1,(uint8_t *)&timeToUnLock,sizeof(timeToUnLock),0xFF);
}

int getTimeToUlock(Rtc *rtc,uint8_t *timeToUnLock){
	return HAL_I2C_Mem_Read(rtc->hi2c, 0xD0, TIME_TO_UNLOCK, 1, (uint8_t *)timeToUnLock, sizeof(*timeToUnLock),0xFF);
}

int getPass(Rtc *rtc,uint32_t *pass){
	return HAL_I2C_Mem_Read(rtc->hi2c, 0xD0, PASS_ADRR, 1, (uint8_t *)pass, sizeof(*pass),0xFF);
}

void SetClockTo01_01_00(Rtc *rtc){
	uint8_t arrData[] = {0,0,0,1,1,1,0};
	HAL_I2C_Mem_Write(rtc->hi2c, 0XD0, 0, 1, arrData, 7, 0XFF);

}
uint8_t getSecFrom01_01_00(Rtc *rtc){
	uint8_t timeOfSec = 0;
	uint8_t readBuff[7];
	HAL_I2C_Mem_Read(rtc->hi2c, 0XD0, 0, 1, readBuff, 7, 0xff);

	timeOfSec = ((readBuff[0] & 15) + (readBuff[0] >> 4)*10 )
	  + ((readBuff[1] & 15) + (readBuff[1] >>4)*10 ) * 60
	  + ((readBuff[2] & 15) + (readBuff[2] >>4)*10 ) * 60 * 60;
	return timeOfSec;
}
