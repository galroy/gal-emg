/*
 * MyMain.h
 *
 *  Created on: Jun 21, 2022
 *      Author: student
 */
#include "main.h"
#ifndef INC_MYMAIN_H_
#define INC_MYMAIN_H_

int mainLoop();

#endif /* INC_MYMAIN_H_ */
