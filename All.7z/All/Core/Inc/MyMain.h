/*
 * MyMain.h
 *
 *  Created on: Jul 13, 2022
 *      Author: USER-PC
 */

#ifndef INC_MYMAIN_H_
#define INC_MYMAIN_H_

void myMain();

#endif /* INC_MYMAIN_H_ */
